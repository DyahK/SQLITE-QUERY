sqlite> SELECT Employee.FirstName, Employee.LastName, Employee.Birthdate FROM Employee;
Nancy|Davolio|1980-12-08
Andrew|Fuller|1984-02-19
Janet|Leverling|1995-08-30
Margaret|Peacock|1969-09-19
Steven|Buchanan|1987-03-04
Michael|Suyama|1995-07-02
Robert|King|1992-05-29
Laura|Callahan|1990-01-09
Anne|Dodsworth|1998-01-27

Note : 
 Sorry Miss, 
 i can't find the region because there's no region column,
 so i made it according to my ability