sqlite> SELECT RegionDescription, FirstName, LastName, bday FROM (SELECT MAX(Employee.Birthdate) as bday, RegionId as rid FROM Employee IN
NER JOIN EmployeeTerritory ON Employee.Id = EmployeeTerritory.EmployeeId INNER JOIN Territory ON TerritoryId = Territory.Id GROUP BY Regio
nId) INNER JOIN (SELECT FirstName, LastName, Birthdate, RegionId, EmployeeId FROM Employee INNER JOIN EmployeeTerritory ON Employee.Id = E
mployeeTerritory.EmployeeId INNER JOIN Territory ON TerritoryId = Territory.Id) ON Birthdate = bday AND rid = RegionId INNER JOIN Region O
N Region.Id = RegionId GROUP BY EmployeeId ORDER BY rid;
Eastern|Steven|Buchanan|1987-03-04
Western|Michael|Suyama|1995-07-02
Northern|Anne|Dodsworth|1998-01-27
Southern|Janet|Leverling|1995-08-30