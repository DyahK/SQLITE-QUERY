sqlite> SELECT pname, CompanyName, ContactName, MIN(OrderDate) 
FROM (SELECT Id AS pid, ProductName as pname FROM Product WHERE Discontinued !=0) 
As Discontinued INNER JOIN OrderDetail on ProductId = pid INNER JOIN 'Order' on 'Order'.Id = OrderDetail.OrderId 
INNER JOIN Customer on CustomerId = Customer.Id GROUP BY pid ORDER BY pname ASC;
Alice Mutton|Consolidated Holdings|Elizabeth Brown|2012-07-10 02:35:32
Chef Anton's Gumbo Mix|Piccolo und mehr|Georg Pipps|2012-07-10 02:48:19
Guaraná Fantástica|Piccolo und mehr|Georg Pipps|2012-07-10 02:48:19
Mishi Kobe Niku|Old World Delicatessen|Rene Phillips|2012-07-10 07:16:19
Perth Pasties|Piccolo und mehr|Georg Pipps|2012-07-10 02:48:19
Rössle Sauerkraut|Piccolo und mehr|Georg Pipps|2012-07-10 02:48:19
Singaporean Hokkien Fried Mee|Vins et alcools Chevalier|Paul Henriot|2012-07-04
Thüringer Rostbratwurst|Piccolo und mehr|Georg Pipps|2012-07-10 02:48:19
