sqlite> SELECT DISTINCT ShipName, SUBSTR(ShipName, 1, 6) FROM 'Order' WHERE ShipName LIKE '%-%' ORDER BY ShipName ASC;
Bottom-Dollar Markets|Bottom
Chop-suey Chinese|Chop-s
GROSELLA-Restaurante|GROSEL
HILARION-Abastos|HILARI
Hungry Owl All-Night Grocers|Hungry
LILA-Supermercado|LILA-S
LINO-Delicateses|LINO-D
QUICK-Stop|QUICK-
Save-a-lot Markets|Save-a