sqlite> SELECT CategoryName, COUNT(1) AS CategoryCount, round(AVG(UnitPrice)), 
MIN(UnitPrice) As MinUnitPrice, MAX(UnitPrice) AS MaxUnitPrice, SUM(UnitsOnOrder) 
AS TotalUnitOnOrder FROM Product INNER JOIN Category on CategoryId = Category.Id 
GROUP BY CategoryId HAVING CategoryCount > 10;
Beverages|12|38.0|4.5|263.5|60
Condiments|12|23.0|10|43.9|170
Confections|13|25.0|9.2|81|180
Seafood|12|21.0|6|62.5|120