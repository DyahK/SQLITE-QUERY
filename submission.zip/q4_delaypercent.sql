sqlite> SELECT CompanyName, ROUND(lambat * 100.0 / lbt, 2) AS pct FROM (SELECT ShipVia, COUNT (*) lbt FROM 'Order' GROUP BY ShipVia) AS jumlah INNER JOIN (SELECT ShipVia, COUNT(*) AS lambat FROM 'Order' WHERE ShippedDate > RequiredDate GROUP BY ShipVia) AS lambat ON jumlah.ShipVia = jumlah.ShipVia INNER JOIN Shipper ON jumlah.ShipVia = Shipper.Id ORDER BY pct DESC;
Speedy Express|23.96
United Package|23.87
Federal Shipping|23.61
Speedy Express|23.53
Speedy Express|23.46
United Package|23.44
United Package|23.37
Federal Shipping|23.19
Federal Shipping|23.12