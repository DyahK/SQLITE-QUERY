sqlite> SELECT Product.Id, Product.ProductName as name FROM Product INNER JOIN OrderDetail on Product.Id = OrderDetail.ProductId INNER JOIN 'Order' ON 'Order'.Id = OrderDetail.OrderId INNER JOIN Customer ON CustomerId = Customer.Id WHERE DATE(OrderDate) = '2014-12-25' AND CompanyName = 'Queen Cozinha'GROUP BY Product.Id;
9|Mishi Kobe Niku
25|NuNuCa Nuß-Nougat-Creme
27|Schoggi Schokolade
32|Mascarpone Fabioli
34|Sasquatch Ale
40|Boston Crab Meat
51|Manjimup Dried Apples
74|Longlife Tofu
76|Lakkalikööri